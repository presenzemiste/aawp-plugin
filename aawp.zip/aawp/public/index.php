<?php
// Silence